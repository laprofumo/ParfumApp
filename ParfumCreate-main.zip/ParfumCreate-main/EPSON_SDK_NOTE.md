# Epson ePOS JS SDK

Aus Lizenzgründen wird `epos-device.js` nicht mitgeliefert.

1) Lade das Epson ePOS-Print SDK (JavaScript) von Epson herunter.
2) Entpacken und kopiere die Datei `epos-device.js` nach:

`public/assets/epos-device.js`

Danach sind Direktdruck & Testbon aktiv.